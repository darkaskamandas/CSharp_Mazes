﻿namespace Maze.generators {
	public class Direction {

		public int x { set; get; }
		public int y { set; get; }

		public Direction() { }
		public Direction(int x, int y) { this.x = x; this.y = y; }

	}
}